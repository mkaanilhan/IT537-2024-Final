<script setup>
import Navbar from '../components/Navbar.vue'
import { ref, onMounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useMovieStore } from '../stores/index'; // Corrected path
import MovieList from '../components/MovieList.vue';

const route = useRoute();
const router = useRouter();
const movieStore = useMovieStore();
const query = ref('');

onMounted(() => {
  query.value = route.query.q || '';
  if (query.value) {
    movieStore.searchMovies(query.value);
  }
});

watch(() => route.query.q, (newQuery) => {
  query.value = newQuery;
  movieStore.searchMovies(query.value);
});
</script>

<template>
  <div>
    <Navbar />
    <h1>Search Results</h1>
    <p>{{ query }}</p>
    <MovieList :movies="movieStore.searchResults" />
  </div>
</template>
