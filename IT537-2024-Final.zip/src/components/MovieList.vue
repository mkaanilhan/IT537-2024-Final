<template>
    <div class="flex flex-wrap justify-center">
      <MovieCard v-for="movie in movies" :key="movie.id" :movie="movie" />
    </div>
  </template>
  
  <script>
  import MovieCard from './MovieCard.vue'
  
  export default {
    name: 'MovieList',
    components: { MovieCard },
    props: {
      movies: Array
    }
  }
  </script>
  