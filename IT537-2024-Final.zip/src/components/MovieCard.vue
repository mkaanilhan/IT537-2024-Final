<template>
    <div class="max-w-xs mx-auto rounded overflow-hidden shadow-lg">
      <router-link :to="{ name: 'MovieDetails', params: { id: movie.id } }">
        <img :src="`https://image.tmdb.org/t/p/w500/${movie.poster_path}`" alt="Movie Poster" class="w-full">
      </router-link>
      <div class="px-6 py-4">
        <div class="font-bold text-xl mb-2">{{ movie.title }}</div>
        
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'MovieCard',
    props: {
      movie: Object
    }
  }
  </script>
  
  <style scoped>
  .truncate {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  </style>
  